#define UTS_RELEASE "3.1.1-15-linaro-omap"
